﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TIC_TAC_TOC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.ForeColor = Color.White;
        }
        
        private void Player(object sender, EventArgs e)
        {

        }
        public void replay()
        {
            //label4.Text += ".";
            //label4.Text += ".";
            //label4.Text += ".";

            button1.Text = string.Empty;
            button2.Text = string.Empty;
            button3.Text = string.Empty;
            button4.Text = string.Empty;
            button5.Text = string.Empty;
            button6.Text = string.Empty;
            button7.Text = string.Empty;
            button8.Text = string.Empty;
            button9.Text = string.Empty;
            button1.BackColor = Color.LightSkyBlue;
            button2.BackColor = Color.LightSkyBlue;
            button3.BackColor = Color.LightSkyBlue;
            button4.BackColor = Color.LightSkyBlue;
            button5.BackColor = Color.LightSkyBlue;
            button6.BackColor = Color.LightSkyBlue;
            button7.BackColor = Color.LightSkyBlue;
            button8.BackColor = Color.LightSkyBlue;
            button9.BackColor = Color.LightSkyBlue;
            label4.Text = "";
            win = 0;
            current = 1;
            fin = 0;
        }
        int win = 0;
        public void Winer()
        {

            if (button1.Text ==button2.Text && button1.Text == button3.Text && button1.Text != "")
            {
                button1.BackColor = Color.White;
                button2.BackColor = Color.White;
                button3.BackColor = Color.White;
                win = 1;
                return;
            }
            if (button4.Text == button5.Text && button4.Text == button6.Text && button4.Text != "")
            {
                button4.BackColor = Color.White;
                button5.BackColor = Color.White;
                button6.BackColor = Color.White;
                win = 1;
                return;
            }
            if (button7.Text == button8.Text && button7.Text == button9.Text && button7.Text != "")
            {
                button7.BackColor = Color.White;
                button8.BackColor = Color.White;
                button9.BackColor = Color.White;
                win = 1;
                return;
            }
            if (button1.Text == button5.Text && button1.Text == button9.Text && button1.Text != "")
            {
                button1.BackColor = Color.White;
                button5.BackColor = Color.White;
                button9.BackColor = Color.White;
                win = 1;
                return;
            }
            if (button1.Text == button4.Text && button1.Text == button7.Text && button1.Text != "")
            {
                button1.BackColor = Color.White;
                button4.BackColor = Color.White;
                button7.BackColor = Color.White;
                win = 1;
                return;
            }
            if (button5.Text == button2.Text && button5.Text == button8.Text && button5.Text != "")
            {
                button5.BackColor = Color.White;
                button2.BackColor = Color.White;
                button8.BackColor = Color.White;
                win = 1;
                return;
            }
            if (button6.Text == button9.Text && button6.Text == button3.Text && button6.Text != "")
            {
                button6.BackColor = Color.White;
                button9.BackColor = Color.White;
                button3.BackColor = Color.White;
                win = 1;
                return;
            }
            if (button3.Text == button5.Text && button3.Text == button7.Text && button3.Text != "")
            {
                button5.BackColor = Color.White;
                button7.BackColor = Color.White;
                button3.BackColor = Color.White;
                win = 1;
                return;
            }
        }
        int current = 1,fin = 0;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            replay();
        }

        private void player(object sender, MouseEventArgs e)
        {
            Button button = (Button)sender;

            if (current == 1 && win == 0)
            {
                
                if (button.Text == "")
                {
                    label1.ForeColor = Color.Black;
                    label2.ForeColor = Color.White;
                    button.Text = "X";
                    current = 0;
                    fin++;
                    if (fin == 9 && win == 0)
                    {
                        label4.Text = "Nobody won!";  
                    }
                }

                Winer();
                if (win == 1)
                {
                    label1.ForeColor = Color.White;
                    label2.ForeColor = Color.Black;
                    label4.Text = "Player 1 is Win";
                }


            }
            else if (current == 0 && win == 0)
            {
                if (button.Text == "")
                {
                    
                    label1.ForeColor = Color.White;
                    label2.ForeColor = Color.Black;
                    button.Text = "O";
                    current = 1;
                    fin++;
                    
                }
                Winer();
                if (win == 1)
                {
                    label1.ForeColor = Color.Black;
                    label2.ForeColor = Color.White;
                    label4.Text = "Player 2 is Win";
                }
                if (fin == 9 && win == 0)
                {
                    label4.Text = "==";
                }
            }
        }
    }
}
